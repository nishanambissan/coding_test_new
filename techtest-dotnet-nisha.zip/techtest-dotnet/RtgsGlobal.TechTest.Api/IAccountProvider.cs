using RtgsGlobal.TechTest.Api.Controllers;

namespace RtgsGlobal.TechTest.Api;

//TODO : would be nice to move to another class/file, cleaner to read
public interface IAccountProvider
{
	MyBalance GetBalance(string accountIdentifier);
	void Deposit(string accountIdentifier, float amount);
	void Transfer(MyTransferDto transfer);
	void Withdraw(string accountIdentifier, float amount);
	bool IsAccountValid(string accountIdentifier);
}

public class AccountProvider : IAccountProvider
{
	//TODO : Account identifiers ideally should be a Guid, reconsider the string along with other things
	private readonly IDictionary<string, MyBalance> _accounts;

	public AccountProvider()
	{
		//I know this is maybe for test purposes only, but this in-memory balance maintaining will be problematic in real life, consider persistent storage.
		//Also this account provider is right now served as Singleton, again being thread safe will be a necessity, persistent storage and Scoped would be safer?
		_accounts = new Dictionary<string, MyBalance> { { "account-a", new MyBalance() }, { "account-b", new MyBalance() } };
	}

	public MyBalance GetBalance(string accountIdentifier) => _accounts[accountIdentifier];

	public void Deposit(string accountIdentifier, float amount) => AddTransaction(accountIdentifier, amount);

	public void Transfer(MyTransferDto transfer)
	{
		AddTransaction(transfer.DebtorAccountIdentifier, -transfer.Amount);
		AddTransaction(transfer.CreditorAccountIdentifier, transfer.Amount);
	}

	public void Withdraw(string accountIdentifier, float amount) => AddTransaction(accountIdentifier, -1 * amount);

	private void AddTransaction(string accountIdentifier, float amount)
	{
		MyBalance accountBalance = _accounts[accountIdentifier];
		_accounts[accountIdentifier] =
			accountBalance with { Balance = accountBalance.Balance + amount };
	}

	//use this method very carefully, can be used by intruders to guess accounts and their existence, so the knowledge of this response should be masked as much as a we can
	public bool IsAccountValid(string accountIdentifier) => _accounts.ContainsKey(accountIdentifier);
}

//TODO : Move to another class
//Also - bigger question - why is Balance a separate entity and why is it not integral to the Account. This does not look right being a separate entity by itself

public record MyBalance(float Balance = 0); //TODO : use decimal please for higher precision
