using System.Security.Cryptography.Xml;
using Microsoft.AspNetCore.Mvc;

namespace RtgsGlobal.TechTest.Api.Controllers;

[ApiController]
[Route("[controller]")] //TODO : Need to double check docs, but I think this is redundant
public class AccountController : ControllerBase
{
	private readonly IAccountProvider _accountProvider;

	public AccountController(IAccountProvider accountProvider)
	{
		_accountProvider = accountProvider;
	}

	[HttpPost("{accountIdentifier}", Name = "Deposit")]
	public IActionResult Deposit(string accountIdentifier, [FromBody] float amount)
	{
		if(!_accountProvider.IsAccountValid(accountIdentifier))
		{
			return NotFound(); 
			//TODO : up for discussion - It could be 401 too, depending on how the other failures propagate, ideally we avoid letting users guess during attacks
		}

		if (amount < 0)
		{
			return BadRequest();
		}

		//TODO : float is lower precision, use decimal instead for financial calculations
		_accountProvider.Deposit(accountIdentifier, amount);
		return Ok();
	}

	[HttpPost("{accountIdentifier}/withdraw", Name = "Withdrawal")]
	public IActionResult Withdraw(string accountIdentifier, [FromBody] float amount)
	{
		if(!_accountProvider.IsAccountValid(accountIdentifier))
		{
			return NotFound(); 
		}

		_accountProvider.Withdraw(accountIdentifier, amount);
		return Ok();
	}

	[HttpPost("transfer", Name = "Transfer")]
	public IActionResult Transfer(MyTransferDto transfer)
	{
		if(!_accountProvider.IsAccountValid(transfer.CreditorAccountIdentifier) || !_accountProvider.IsAccountValid(transfer.DebtorAccountIdentifier))
		{
			return NotFound(); 
		}

		if (transfer.CreditorAccountIdentifier == transfer.DebtorAccountIdentifier)
		{
			return BadRequest("Creditor and Debitor accounts cannot be the same");
		}

		_accountProvider.Transfer(transfer);
		return Accepted();
	}

	[HttpGet("{accountIdentifier}", Name = "GetBalance")]
	public IActionResult Get(string accountIdentifier)
	{
		if(!_accountProvider.IsAccountValid(accountIdentifier))
		{
			return NotFound();
		}

		return Ok(_accountProvider.GetBalance(accountIdentifier));
	}
}

//TODO : Move this to another place, this is not the right place to have Dtos, also rename it to Transfer or TransferDto
public class MyTransferDto
{
	public MyTransferDto(string debtorAccountIdentifier, string creditorAccountIdentifier, float amount)
	{
		DebtorAccountIdentifier = debtorAccountIdentifier;
		CreditorAccountIdentifier = creditorAccountIdentifier;
		Amount = amount;
	}

	public string DebtorAccountIdentifier { get; set; }
	public string CreditorAccountIdentifier { get; set; }
	public float Amount { get; set; } //TODO change to decimal
}
