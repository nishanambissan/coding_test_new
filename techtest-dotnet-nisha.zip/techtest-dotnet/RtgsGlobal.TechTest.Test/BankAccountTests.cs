using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using RtgsGlobal.TechTest.Api;
using RtgsGlobal.TechTest.Api.Controllers;
using Xunit;

namespace RtgsGlobal.TechTest.Test;

public class BankAccountTests : IClassFixture<WebApplicationFactory<Program>>
{
	private readonly HttpClient _client;

	public BankAccountTests(WebApplicationFactory<Program> fixture)
	{
		_client = fixture
			.WithWebHostBuilder(builder => builder.ConfigureServices(services =>
			{
				services.AddSingleton<IAccountProvider, AccountProvider>();
			}))
			.CreateDefaultClient();
	}

	//TODO : This is running with no guarantee on sequence, singleton account provider instance and in memory balance, we can't be sure that these tests always pass
	//What is the transfer test ran first and the balance was not 0 to start with?

	#region Validation tests

	//TODO : consider grouping actions and their valdiations together in indiividual test files, like WithdrawTests or DepositTests, etc
	[Fact]
	public async Task GivenNoAccountExistsWithNoProvidedIdentifier_ThenGetBalanceReturnsNotFound()
	{
		var result = await _client.GetAsync("/account/non-existent-account");

		Assert.Equal(HttpStatusCode.NotFound, result.StatusCode);
	}

	[Fact]
	public async Task GivenNoAccountExistsWithNoProvidedIdentifier_ThenWithdrawReturnsNotFound()
	{
		var result = await _client.PostAsJsonAsync("/account/non-existent-account/withdraw", "100");

		Assert.Equal(HttpStatusCode.NotFound, result.StatusCode);
	}

	[Fact]
	public async Task GivenNoAccountExistsWithNoProvidedIdentifier_ThenDepositReturnsNotFound()
	{
		var result = await _client.PostAsJsonAsync("/account/non-existent-account", "2000");

		Assert.Equal(HttpStatusCode.NotFound, result.StatusCode);
	}

	[Fact]
	public async Task GivenNoAccountExistsWithNoProvidedCreditorIdentifier_ThenTransferReturnsNotFound()
	{
		var result =
			await _client.PostAsJsonAsync("/account/transfer", new MyTransferDto("account-a", "non-existent-account", 1000));

		Assert.Equal(HttpStatusCode.NotFound, result.StatusCode);
	}

	[Fact]
	public async Task GivenNoAccountExistsWithNoProvidedDebitorIdentifier_ThenTransferReturnsNotFound()
	{
		var result =
			await _client.PostAsJsonAsync("/account/transfer", new MyTransferDto("non-existent-account", "account-b", 1000));

		Assert.Equal(HttpStatusCode.NotFound, result.StatusCode);
	}

	#endregion

	[Fact]
	public async Task GivenAccountExistsWithNoTransactions_ThenGetBalanceShouldReturnZero()
	{
		var result = await _client.GetFromJsonAsync<MyBalance>("/account/account-a");

		Assert.Equal(0, result.Balance);
	}

	[Fact]
	public async Task GivenAccountExists_WhenDepositIsAddedForNegativeAmount_ThenReturnBadRequest()
	{
		var result = await _client.PostAsJsonAsync("/account/account-a", "-1000");

		Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);
	}

	[Fact]
	public async Task GivenAccountExists_WhenDepositIsAdded_ThenGetBalanceShouldReturnExpected()
	{
		await _client.PostAsJsonAsync("/account/account-a", "1000");
		var result = await _client.GetFromJsonAsync<MyBalance>("/account/account-a");

		Assert.Equal(1000, result.Balance);
	}

	[Fact]
	public async Task GivenAccountExistsAndDepositIsAdded_WhenWithdrawalIsAdded_ThenGetBalanceShouldReturnExpected()
	{
		await _client.PostAsJsonAsync("/account/account-a", "1000");

		await _client.PostAsJsonAsync("/account/account-a/withdraw", "100");
		var result = await _client.GetFromJsonAsync<MyBalance>("/account/account-a");

		Assert.Equal(900, result.Balance);
	}

	[Fact]
	public async Task GivenAccountExists_WhenMultipleDepositsAreAdded_ThenGetBalanceShouldReturnExpected()
	{
		await _client.PostAsJsonAsync("/account/account-a", "1000");
		await _client.PostAsJsonAsync("/account/account-a", "2000");
		var result = await _client.GetFromJsonAsync<MyBalance>("/account/account-a");

		Assert.Equal(3000, result.Balance);
	}

	[Fact]
	public async Task GivenAccountExists_WhenTransferIsMadeToSelf_ThenShouldReturnBadRequest()
	{
		var result = await _client.PostAsJsonAsync("/account/transfer", new MyTransferDto("account-a", "account-a", 1000));

		Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);
	}

	[Fact]
	public async Task GivenAccountExists_WhenTransferIsMade_ThenGetBalanceShouldReturnExpected()
	{
		await _client.PostAsJsonAsync("/account/transfer", new MyTransferDto("account-a", "account-b", 1000));
		var accountA = await _client.GetFromJsonAsync<MyBalance>("/account/account-a");
		var accountB = await _client.GetFromJsonAsync<MyBalance>("/account/account-b");

		Assert.Equal(-1000, accountA.Balance);
		Assert.Equal(1000, accountB.Balance);
	}
}
